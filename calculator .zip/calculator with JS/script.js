function data(val) {
    Calculator.display.value += val;

}

function clearAll() {
    Calculator.display.value = "";
}

function clearLast() {
    Calculator.display.value = Calculator.display.value.slice(0, -1);
}

function operationResult() {
    Calculator.display.value = eval(Calculator.display.value);
}
// eval it is a function of script get the string and do mathmatichal operation on it and return the value or result.